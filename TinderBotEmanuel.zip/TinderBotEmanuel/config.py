# Author: Stan Fortoński
# Date: 02.05.2020
# Config

import json

with open('config.json') as file:
    Config = json.load(file)